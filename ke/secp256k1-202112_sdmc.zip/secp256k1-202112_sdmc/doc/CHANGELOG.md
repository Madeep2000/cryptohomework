# Changelog

This file is currently only a template for future use.

Each change falls into one of the following categories: Added, Changed, Deprecated, Removed, Fixed or Security.

## [Unreleased]

## [MAJOR.MINOR.PATCH] - YYYY-MM-DD

### Added/Changed/Deprecated/Removed/Fixed/Security
- [Title with link to Pull Request](https://link-to-pr)
